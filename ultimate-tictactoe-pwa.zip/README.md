# Ultimate Tic Tac Toe (PWA)

A lightweight, hardware-free web app. Works offline and can be installed on phones (PWA).

## Files
- `index.html` – the entire game UI + logic
- `manifest.webmanifest` – PWA manifest
- `sw.js` – service worker for offline caching
- `icons/` – app icons (192px & 512px)

## Quick Preview (local)
1. Use any static server (recommended):
   - Python 3: `python -m http.server 8000`
   - Node: `npx serve`
2. Open: http://localhost:8000

> Opening `index.html` by double-click may not register the service worker—serve it over `http://` or `https://`.

## Deploy Options

### Option A — GitHub Pages (free)
1. Create a repo and upload these files at the root.
2. In GitHub repo settings → Pages → set Source to **`main`** branch (or docs) root.
3. Wait a bit, your site will be live at `https://<your-username>.github.io/<repo>/`.

### Option B — Netlify (free)
1. Drag-and-drop this folder at https://app.netlify.com/drop
2. Or connect your GitHub repo → set build command to **none** and publish directory to `/`.

### Option C — Vercel (free)
1. `vercel` (CLI) or import the GitHub repo in Vercel.
2. Framework preset: **Other** (static). Output directory: `/`.

## Install as an app (PWA)
- Visit your site on Chrome/Edge/Brave/Android → **Install App** prompt, or browser menu → Add to Home Screen.
- iOS Safari → Share → **Add to Home Screen**.

Enjoy!
